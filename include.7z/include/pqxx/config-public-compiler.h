/* Define if compiler supports [[deprecated]] attribute */
#define PQXX_HAVE_DEPRECATED 1

/* Define if the compiler supports std::experimental::optional. */
/* #undef PQXX_HAVE_EXP_OPTIONAL */

/* Define if the compiler supports std::optional. */
/* #undef PQXX_HAVE_OPTIONAL */
